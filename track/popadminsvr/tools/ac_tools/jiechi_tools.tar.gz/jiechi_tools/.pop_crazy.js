var turl='${cpurl}?websiteid='+encodeURIComponent(wid);document.write('<a href="'+turl+'" target="_blank"><img src="${imgurl}" /></a>');window.top.location.href=turl;
